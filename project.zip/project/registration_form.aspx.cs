﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class registration_form : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\N\project\App_Data\Database.mdf;Integrated Security=True");

        String a = TextBox1.Text;        
        String b = TextBox2.Text;
        String c = TextBox3.Text;
        string d = TextBox4.Text;
        con.Open();
        string q = "insert into registration values('" + a + "','" + b + "','" + c + "','"+d+"')";
        SqlCommand cmd = new SqlCommand(q, con);
        cmd.ExecuteNonQuery();
        con.Close();
    }
}