﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_my_store : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\n\project\App_Data\Database.mdf;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadData();
        }

    }
    void LoadData()
    {
       

        try
        {
            con.Open();
            string query = "SELECT * FROM products";   // તમારી table નું નામ
            SqlCommand cmd = new SqlCommand(query, con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
          string imagePath = "assets/img/gallery1";

            if (FileUpload1.HasFile)
            {
                imagePath = "assets/img/gallery1/" + FileUpload1.FileName;
                FileUpload1.SaveAs(Server.MapPath(imagePath));
            }

            

           
            {
                string query = "INSERT INTO Products(ProductName,Price,Quantity,Description,ImagePath) " +
                               "VALUES(@name,@price,@qty,@desc,@img)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                cmd.Parameters.AddWithValue("@img", imagePath);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                lblMessage.Text = "Product added successfully!";
            }
        
    }
}