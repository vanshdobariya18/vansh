﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\nensi\project\App_Data\Database.mdf;Integrated Security=True");

    
    protected void Page_Load(object sender, EventArgs e)
    {

        ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;


    }

   
    protected void Button1_Click2(object sender, EventArgs e)
    {

        String a = TextBox1.Text;
        String b = TextBox2.Text;
        String c = TextBox3.Text;
        string d = TextBox4.Text;
        con.Open();
        string q = "insert into registration values('" + a + "','" + b + "','" + c + "','" + d + "')";
        SqlCommand cmd = new SqlCommand(q, con);
        int i=cmd.ExecuteNonQuery();
        if(i>0)
        {
            
        }
        else
        {

        }
        con.Close();
        //Response.Redirect("login.aspx");
    }
}